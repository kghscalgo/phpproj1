<!DOCTYPE html>
<html>
<head>
<title>Exponential Amount Calculation</title>
</head>
<body>


<?php
// static class addnumbers
// {
//     public function addtwono($num1,$num2)
//     {
//         echo $num1;
//         echo $num2;
//         return ($num1*$num2);
//     }

// }
// echo addtwono(5,5);
// $m=new addnumbers();
// $validationResult = $m->addtwono(5,5);
// echo $validationResult;
// class A {
//     public function methodA() {
//         echo "Method A";
//     }
// }

// class B extends A {
//     public function methodB() {
//         echo "Method B";
//     }
// }

// class C extends B {
//     public function methodC() {
//         echo "Method C";
//     }
// }

// $c = new C();
// $c->methodA(); // Output: Method A
// $c->methodB(); // Output: Method B
// $c->methodC(); 
?>
</body>
</html>