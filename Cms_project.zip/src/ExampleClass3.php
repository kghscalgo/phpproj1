<?php

namespace Project\Cms;

class ExampleClass3
{
    public function mul()
    {
        return "<p style='font-size: 24px;'>Hello Welcome to your new project setup current page 3!</p>";
    }
}
$exam=new ExampleClass3();
echo $exam->mul();