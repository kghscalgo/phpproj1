<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog View</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .filter-form {
            margin-bottom: 20px;
        }
        .filter-form label {
            margin-right: 10px;
            font-weight: bold;
        }
        .filter-form select, .filter-form input {
            margin-right: 10px;
            padding: 5px;
        }
        .post {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }
        .post:last-child {
            border-bottom: none;
        }
        .post h2 {
            color: #555;
        }
        .post p {
            color: #777;
        }
        .post .meta {
            font-size: 14px;
            color: #999;
        }
        .post .read-more {
            display: inline-block;
            margin-top: 10px;
            padding: 5px 10px;
            background-color: #5cb85c;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .pagination {
            text-align: center;
            margin-top: 20px;
        }
        .pagination a {
            display: inline-block;
            padding: 8px 16px;
            margin: 0 4px;
            background-color: #5cb85c;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .pagination a.active {
            background-color: #4cae4c;
        }
        .pagination a:hover {
            background-color: #4cae4c;
        }
        .no-posts {
            text-align: center;
            color: #888;
            font-size: 18px;
            margin-top: 20px;
        }
        button {
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #5cb85c;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Blog Posts</h1>
    <button onclick="window.location.href='?url=welcome'">Dashboard</button>

    <form method="GET" action="" class="filter-form">
        <input type="hidden" name="url" value="bview">
        <label for="category">Category:</label>
        <select name="category" id="category">
            <option value="">All</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?php echo $category['id']; ?>" <?php echo (isset($_GET['category']) && $_GET['category'] == $category['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($category['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="status">Status:</label>
        <select name="status" id="status">
            <option value="">All</option>
            <option value="published" <?php echo (isset($_GET['status']) && $_GET['status'] == 'published') ? 'selected' : ''; ?>>Published</option>
            <option value="archived" <?php echo (isset($_GET['status']) && $_GET['status'] == 'archived') ? 'selected' : ''; ?>>Archived</option>
            <option value="rejected" <?php echo (isset($_GET['status']) && $_GET['status'] == 'rejected') ? 'selected' : ''; ?>>Rejected</option>
        </select>

        <label for="start_date">Start Date:</label>
        <input type="date" name="start_date" id="start_date" value="<?php echo isset($_GET['start_date']) ? $_GET['start_date'] : ''; ?>">

        <label for="end_date">End Date:</label>
        <input type="date" name="end_date" id="end_date" value="<?php echo isset($_GET['end_date']) ? $_GET['end_date'] : ''; ?>">

        <button type="submit">Filter</button>
    </form>

    <?php if (empty($posts)): ?>
        <p class="no-posts">No post to show. Post first!</p>
        <button onclick="window.location.href='?url=uart'">Add-Article</button>
    <?php else: ?>
        <?php foreach ($posts as $post): ?>
            <div class="post">
                <h2><?php echo htmlspecialchars($post['title']); ?></h2>
                <p class="meta">by <?php echo htmlspecialchars($post['username']); ?> | <?php echo htmlspecialchars($post['email']); ?> | <?php echo htmlspecialchars($post['category_name']); ?> | <?php echo date('F j, Y', strtotime($post['created'])); ?>| <?php echo htmlspecialchars($post['status']); ?></p>
                <p><?php echo htmlspecialchars(substr($post['message'], 0, 100)) . '...'; ?></p>
                <a class="read-more" href="?url=bread&id=<?php echo $post['id']; ?>">Read More</a>
            </div>
        <?php endforeach; ?>

        <div class="pagination">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?url=bview&page=<?php echo $i; ?><?php echo $category_filter ? '&category=' . $category_filter : ''; ?><?php echo $status_filter ? '&status=' . $status_filter : ''; ?><?php echo $start_date_filter ? '&start_date=' . $start_date_filter : ''; ?><?php echo $end_date_filter ? '&end_date=' . $end_date_filter : ''; ?>" <?php echo ($i == $page) ? 'class="active"' : ''; ?>>
                    <?php echo $i; ?>
                </a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
