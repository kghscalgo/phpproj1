<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Articles</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .edit, .delete {
            cursor: pointer;
            color: blue;
        }
        button {
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #5cb85c;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #4cae4c;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
            padding-top: 60px;
        }
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .edit{
    display: block;
    text-align: right;
}
.edit{
    padding: 10px 20px;
    background-color: #5cb85c;
    color: white;
    border: none;
    cursor: pointer;
    border-radius: 5px;
}
    </style>
</head>
<body>

<h1>Manage Articles</h1>
<button onclick="window.location.href='?url=welcome'">Dashboard</button>
<button onclick="window.location.href='?url=uart'">Add-New</button>

<?php if (empty($articles)): ?>
    <p>Not yet posted.</p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th>SN</th>
                <th>Title</th>
                <th>Message</th>
                <th>Category</th>
                <th>Username</th>
                <th>Status</th>
                <th>Created</th>
                <th>Updated</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($articles as $index => $article): ?>
                <tr>
                    <td><?php echo $index + 1; ?></td>
                    <td><?php echo htmlspecialchars($article['title']); ?></td>
                    <td><?php echo htmlspecialchars($article['message']); ?></td>
                    <td><?php echo htmlspecialchars($article['category_name']); ?></td>
                    <td><?php echo htmlspecialchars($article['username']); ?></td>
                    <td><?php echo htmlspecialchars($article['status']); ?></td>
                    <td><?php echo htmlspecialchars($article['created']); ?></td>
                    <td><?php echo htmlspecialchars($article['updated']); ?></td>
                    <td>
                        <span class="edit" onclick="editArticle(<?php echo $index; ?>)">Edit</span> |
                        <form action="?url=mart" method="post" style="display:inline;">
                            <button type="submit" name="delete" value="1" onclick="return confirm('Do you want to delete?');">Delete</button>
                            <input type="hidden" name="article_id" value="<?php echo $article['id']; ?>">
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Modal for editing article -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <form action="?url=mart" method="post">
                <input type="hidden" name="article_id" id="article_id">
                <label for="title">Title:</label>
                <input type="text" name="title" id="title" required><br><br>
                <label for="message">Message:</label>
                <textarea name="message" id="message" required></textarea><br><br>
                <label for="status">Status:</label>
                <select name="status" id="status">
                    <option value="published">Published</option>
                    <option value="archived">Archived</option>
                    <option value="rejected">Rejected</option>
                </select><br><br>
                <label for="category_id">Category:</label>
                <select name="category_id" id="category_id">
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                    <?php endforeach; ?>
                </select><br><br>
                <button type="submit" name="update">Save</button>
            </form>
        </div>
    </div>

<?php endif; ?>

<script>
    function editArticle(index) {
        const article = <?php echo json_encode($articles); ?>[index];
        document.getElementById('article_id').value = article.id;
        document.getElementById('title').value = article.title;
        document.getElementById('message').value = article.message;
        document.getElementById('status').value = article.status;
        document.getElementById('category_id').value = article.category_id;
        document.getElementById('editModal').style.display = "block";
    }

    function closeModal() {
        document.getElementById('editModal').style.display = "none";
    }
</script>

</body>
</html>
