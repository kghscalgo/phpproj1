<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="views/js/manage.js"></script>
</body>
</html>
