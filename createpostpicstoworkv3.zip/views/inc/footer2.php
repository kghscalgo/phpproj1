<script src="views/js/cat.js"></script>
</body>
</html>